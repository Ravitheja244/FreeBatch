package com.SpiceJet.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.SpiceJet.PageObjects.BookingPage;

import Resources.ConfigReader;

public class MainTestCases {

	WebDriver driver =new ChromeDriver();
	@BeforeClass
	public void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\tallamravi.t\\Desktop\\chromedriver.exe");
		driver.manage().window().maximize();
		driver.get("https://www.spicejet.com/");	
	}
	
	@Test(priority=1,enabled=false,description="To verify the Booking page of SpiceJet Application.")
	public void VerifyBookingPage()
	{
		String Actual=driver.getTitle();
		Assert.assertTrue(Actual.contains("SpiceJet"), "SpiceJet application isnt loaded succesfully.");
		System.out.println("Spicejet Application loaded.");
	}
	
	@Test (priority=2,enabled=true,description="Going to search the Flights for two different cities.")
	public void SearchFlights() throws Exception
	{
		BookingPage bookingpage=new BookingPage();
		bookingpage.departuredropdown(driver).click();
		ConfigReader config=new ConfigReader();
		bookingpage.SelectTheDepartureCity(driver, config.getKeyValue("DepartureCity"));
		bookingpage.SelectTheArrivalCity(driver, config.getKeyValue("ArrivalCity"));
		bookingpage.DatePicker(driver, config.getKeyValue("DepartureMonth"), config.getKeyValue("DepartureDate"));
		//bookingpage.ClickonPassengerDropDown(driver);
		
	}
	
	@AfterClass
	public void teardown()
	{
		driver.close();
	}
}
