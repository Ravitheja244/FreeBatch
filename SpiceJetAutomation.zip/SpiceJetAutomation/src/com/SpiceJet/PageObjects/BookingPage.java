package com.SpiceJet.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class BookingPage {
	
	public By DepartureDropdown=By.id("ctl00_mainContent_ddl_originStation1_CTXT");
	public By ListOfCitiesUnderDeparture=By.xpath("//div[@class='search_options_menucontent']//li/a");
	public By ListOfArrivalCities=By.xpath("(//div[@class='search_options_menucontent'])[2]//li/a");
	public By MonthXpath=By.xpath("(//div[@class='ui-datepicker-title'])[1]/span[@class='ui-datepicker-month']");
	public By DateXpath=By.xpath("(//table[@class='ui-datepicker-calendar'])[1]//a");
	public By PassengerDropdown=By.xpath("//div[@id='divpaxinfo']");
	public By AdultDropDown=By.xpath("//select[@id='ControlGroupSearchView_AvailabilitySearchInputSearchView_DropDownListPassengerType_ADT'");
	public By ChildDropDown=By.xpath("//select[@id='ControlGroupSearchView_AvailabilitySearchInputSearchView_DropDownListPassengerType_CHD']");
	public By InfantDropDown=By.xpath("//select[@id='ControlGroupSearchView_AvailabilitySearchInputSearchView_DropDownListPassengerType_INFANT']");
			
	public WebElement departuredropdown(WebDriver driver)
	{
		return driver.findElement(DepartureDropdown);
	}
	 
	public void ClickonPassengerDropDown(WebDriver driver)
	{
		driver.findElement(PassengerDropdown).click();
	}
	
	public void SelectTheDepartureCity(WebDriver driver,String Cityname)
	{
		List<WebElement> listofcities=driver.findElements(ListOfCitiesUnderDeparture);
		
		for(int i=0;i<listofcities.size();i++) {			
			WebElement City=listofcities.get(i);
			String cityname=City.getText();
			if(cityname.contains(Cityname))
			{
				City.click();
			}
	
		}
		
	}
	
	public void SelectTheArrivalCity(WebDriver driver,String Cityname)
	{
		List<WebElement> listofcities=driver.findElements(ListOfArrivalCities);
		
		for(int i=0;i<listofcities.size();i++) {			
			WebElement City=listofcities.get(i);
			String cityname=City.getText();
			if(cityname.contains(Cityname))
			{
				City.click();
			}
	
		}
		
	}
	
	public void DatePicker(WebDriver driver,String MonthValue,String DateValue) throws Exception
	{
		List<WebElement> allmonths=driver.findElements(MonthXpath);
		
		for(int i=0;i<allmonths.size();i++)
		{
			String Month=driver.findElements(MonthXpath).get(i).getText();
			if(MonthValue.contains(Month))
			{
				List<WebElement> alldates=driver.findElements(DateXpath);
				
				for(int j=0;j<alldates.size();j++)
				{
					WebElement date=alldates.get(j);
					if(DateValue.equalsIgnoreCase(date.getText()))
					{
						date.click();
						break;
						
					}
				}
							
			}
			else
			{
				driver.findElement(By.xpath("//span[text()='Next']")).click();
				Thread.sleep(3000);
				i=-1;
			}
			
		}
		
	}

//	public void SelectNo.OfAdultsFromDropDown(WebDriver driver,String value)
//	{
//		Select selectmyvluefromdropdown=new Select(driver.findElement(AdultDropDown));
//		selectmyvluefromdropdown.selectByVisibleText(value);
//	}
//	
//	public void SelectNo.OfChildFromDropDown(WebDriver driver,String dropdownxpath,String value)
//	{
//		Select selectmyvluefromdropdown=new Select(driver.findElement());
//		selectmyvluefromdropdown.selectByVisibleText(value);
//	}
//	
//	public void SelectNo.OfInfantFromDropDown(WebDriver driver,String dropdownxpath,String value)
//	{
//		Select selectmyvluefromdropdown=new Select(driver.findElement(By.xpath(dropdownxpath)));
//		selectmyvluefromdropdown.selectByVisibleText(value);
//	}
}
