package Resources;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {

	
	public String getKeyValue(String Key) throws Exception
	{
		FileReader fr=new FileReader("C:\\Users\\tallamravi.t\\eclipse-workspace\\Day03_Sessions\\src\\Resources\\Config.properties");
		Properties p=new Properties();
		p.load(fr);
		return p.getProperty(Key);
		
	}
}
