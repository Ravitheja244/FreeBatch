import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\tallamravi.t\\Desktop\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.id("ul-btn")).click();
//		driver.findElement(By.id("email")).sendKeys("teja.ravi244@gmail.com");
	//	driver.findElement(By.name("login_password")).sendKeys("ravitheja");
		driver.findElement(By.partialLinkText("Assistance")).click();
		Thread.sleep(5000);
		driver.close();
	}
}
