import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHandlings {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\tallamravi.t\\Desktop\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.spicejet.com/");
		Thread.sleep(5000);
		WebElement Login=driver.findElement(By.xpath("(//a[text()='Login / Signup'])[1]"));
		
		Base baseactions=new Base();
		baseactions.MouseHover(driver, Login);
		
		WebElement SpiceClubMembers=driver.findElement(By.xpath("//a[text()='SpiceClub Members']"));
		baseactions.MouseHover(driver, SpiceClubMembers);
	
		WebElement MemberLogin=driver.findElement(By.xpath("(//a[text()='Member Login'])[2]"));
		baseactions.MouseClick(driver, MemberLogin);
		
		
		
		
		Thread.sleep(6000);
		driver.close();
		
	}

}
