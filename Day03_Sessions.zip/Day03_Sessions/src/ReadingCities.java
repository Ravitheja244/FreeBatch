import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReadingCities {

	public static void main(String[] args) throws Exception {
	
		try {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\tallamravi.t\\Desktop\\chromedriver.exe");
			WebDriver driver =new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.spicejet.com/");
			Thread.sleep(5000);
			
			driver.findElement(By.xpath("//span[@id='ctl00_mainContent_ddl_originStation1_CTXTaction']")).click();

			Base base=new Base();
			
			//Below input is for Departure city
			base.SelectTheDepartureAndArrivalCity(driver, "//div[@class='search_options_menucontent']//li/a", "Surat");
			
			//Below input is for Arrival city
			base.SelectTheDepartureAndArrivalCity(driver, "(//div[@class='search_options_menucontent'])[2]//li/a", "Varanasi");
			
			//Below input is for DatePicker.
			base.DatePicker(driver, "(//div[@class='ui-datepicker-title'])[1]/span[@class='ui-datepicker-month']", "December", "(//table[@class='ui-datepicker-calendar'])[1]//a", "30");
		
			//Below input is for Passenger details.
			driver.findElement(By.xpath("//div[@id='divpaxinfo']")).click();
			
			//Below input is for Adult
			base.SelectMyValueFromDropDown(driver, "//select[@name='ctl00$mainContent$ddl_Adult']", "3");
			
			//Below input is for Child
			base.SelectMyValueFromDropDown(driver, "//select[@name='ctl00$mainContent$ddl_Child']", "2");
			
			//Below input is for Infant
			base.SelectMyValueFromDropDown(driver, "//select[@name='ctl00$mainContent$ddl_Child']", "1");
			
			//Selecting the currency
			base.SelectMyValueFromDropDown(driver, "//select[@name='ctl00$mainContent$DropDownListCurrency']", "USD");
		
			//Clicking on Search button
			driver.findElement(By.xpath("(//span[@class='btn-find-flight-home']/input)[1]")).click();
	
		
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
	}

}


