import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Base {

	public void MouseHover(WebDriver driver,WebElement webelement)
	{
		Actions act=new Actions(driver);
		act.moveToElement(webelement).build().perform();
	}
	
	public void MouseClick(WebDriver driver,WebElement webelement)
	{
		Actions act=new Actions(driver);
		act.moveToElement(webelement).click().build().perform();;
		
	}
	
	public void SelectTheDepartureAndArrivalCity(WebDriver driver,String elementxpath,String Cityname)
	{
		List<WebElement> listofcities=driver.findElements(By.xpath(elementxpath));
		
		for(int i=0;i<listofcities.size();i++) {			
			WebElement City=listofcities.get(i);
			String cityname=City.getText();
//			System.out.println(cityname);
			if(cityname.contains(Cityname))
			{
				City.click();
			}
	
		}
		
	}

	public void DatePicker(WebDriver driver,String Monthxpath,String MonthValue,String DateXpath,String DateValue) throws Exception
	{
		List<WebElement> allmonths=driver.findElements(By.xpath(Monthxpath));
		
		for(int i=0;i<allmonths.size();i++)
		{
			String Month=driver.findElements(By.xpath(Monthxpath)).get(i).getText();
			if(MonthValue.contains(Month))
			{
				List<WebElement> alldates=driver.findElements(By.xpath(DateXpath));
				
				for(int j=0;j<alldates.size();j++)
				{
					WebElement date=alldates.get(j);
					if(DateValue.equalsIgnoreCase(date.getText()))
					{
						date.click();
						break;
						
					}
				}
							
			}
			else
			{
				driver.findElement(By.xpath("//span[text()='Next']")).click();
				Thread.sleep(3000);
				i=-1;
			}
			
		}
		
	}

	public void SelectMyValueFromDropDown(WebDriver driver,String dropdownxpath,String value)
	{
		Select selectmyvluefromdropdown=new Select(driver.findElement(By.xpath(dropdownxpath)));
		selectmyvluefromdropdown.selectByVisibleText(value);
	}
	


}
